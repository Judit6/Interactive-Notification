//
//  ViewController.swift
//  InteractiveNotification
//
//  Created by MaryJudit on 30/05/17.
//  Copyright © 2017 ndotmac. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController,UNUserNotificationCenterDelegate {
    
    @IBOutlet var labelDetail: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        //Add Action
        let commentAction = UNTextInputNotificationAction(identifier: "comment", title: "Add Comment", options: [], textInputButtonTitle: "Add", textInputPlaceholder: "Add Comment Here")
        let category = UNNotificationCategory(identifier: "myCategory",actions: [commentAction],intentIdentifiers: [], options: [.customDismissAction])
        UNUserNotificationCenter.current().setNotificationCategories([category])
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK:- Create Notification
    @IBAction func notifyTapped(_ sender: AnyObject){
        // Create Notification Content
        let notificationContent = UNMutableNotificationContent()
        notificationContent.title = "Reminder"
        notificationContent.body = "Hi,dude..Good Morning.Have a Great Day.."
        notificationContent.categoryIdentifier = "myCategory"
        notificationContent.sound = UNNotificationSound.default()
        if let path = Bundle.main.path(forResource: "logo", ofType: "jpg") {
            let url = URL(fileURLWithPath: path)
            do {
                let attachment = try UNNotificationAttachment(identifier: "logo", url: url, options: nil)
                notificationContent.attachments = [attachment]
            } catch {
                print("The attachment was not loaded.")
            }
        }
        //Triggers are the events which set off a notification
        let notificationTrigger = UNTimeIntervalNotificationTrigger(timeInterval: 2,repeats: false)
        let request = UNNotificationRequest(identifier: "remindSkip.category.ios",content: notificationContent,trigger: notificationTrigger)
        UNUserNotificationCenter.current().delegate = self
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
        UNUserNotificationCenter.current().add(request, withCompletionHandler: { (error) in
            if let error = error {
                print("Error \(error)")
            }
        })
    }
    //MARK:- UNUserNotificationCenterDelegate
    
    //Call when we tap a notification
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        print("Tapped in notification")
        print("Recieved Action For \(response.actionIdentifier)")
        if response.actionIdentifier == "comment"{
            let textResponse = response as! UNTextInputNotificationResponse
            labelDetail.text = textResponse.userText
            let content = UNMutableNotificationContent()
            content.body = textResponse.userText
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 2,repeats: false)
            let request = UNNotificationRequest(identifier: "remindSkip.category.ios",content: content,trigger: trigger)
            UNUserNotificationCenter.current().add(request, withCompletionHandler:nil)
        }
        completionHandler()
    }
    //call notification will present
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        print("Notification being triggered")
        completionHandler([.alert,.sound,.badge])
    }
}




